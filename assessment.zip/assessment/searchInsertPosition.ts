/**
 * Searches for a target value in a sorted array of distinct integers using binary search.
 * If the target is found, returns its index. If not, returns the index where it would be inserted.
 * @param nums Sorted array of distinct integers.
 * @param target Target value to search for.
 * @returns The index of the target if found, otherwise the index where it should be inserted.
 */
export const searchInsertPosition = (nums: number[], target: number): number => {
  let leftIndex = 0; // Initialize left pointer
  let rightIndex = nums.length - 1; // Initialize right pointer

  while (leftIndex <= rightIndex) {
    // Perform binary search until left pointer crosses the right pointer
    const midIndex = Math.floor((leftIndex + rightIndex) / 2); // Calculate middle index

    if (nums[midIndex] === target) {
      // If target is found at middle index
      return midIndex;
    } else if (nums[midIndex] < target) {
      // If target is greater than value at middle index
      leftIndex = midIndex + 1; // Move left pointer to the right
    } else {
      // If target is less than value at middle index
      rightIndex = midIndex - 1; // Move right pointer to the left
    }
  }

  return leftIndex; // If not found, left represents the index where it should be inserted
};

// Test cases
console.log(searchInsertPosition([1, 3, 5, 6], 5)); // Output: 2
console.log(searchInsertPosition([1, 3, 5, 6], 2)); // Output: 1
console.log(searchInsertPosition([1, 3, 5, 6], 7)); // Output: 4
