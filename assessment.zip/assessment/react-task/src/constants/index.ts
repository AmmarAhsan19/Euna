export const CHARCTERS_ONLY_REGEX = /^[a-zA-Z]*$/;
