import React, { useCallback, useState } from "react";
import { z } from "zod";

import styles from "./App.module.css";
import { nameSchema } from "./schemas/nameSchema";

const App: React.FC = () => {
  const [name, setName] = useState<string>("");
  const [age, setAge] = useState<number>(1);
  const [errors, setErros] = useState<string[]>([]);

  const handleNameChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      setName(e.target.value);
      try {
        nameSchema.parse(e.target.value);
        setErros([]);
      } catch (err) {
        if (err instanceof z.ZodError) {
          setErros(err.issues.map((error) => error.message));
        }
      }
    },
    []
  );

  const increaseAge = useCallback(() => setAge((prevAge) => prevAge + 1), []);
  const decreaseAge = useCallback(() => setAge((prevAge) => prevAge - 1), []);

  return (
    <div className={styles.AppContainer}>
      <h1>Enter your name and age</h1>
      <div className={styles.FormContainer}>
        <form className={styles.Form} onSubmit={(e) => e.preventDefault()}>
          <label htmlFor="name">Name:</label>
          <input
            type="text"
            name="name"
            value={name}
            onChange={handleNameChange}
            className={styles.Input}
          />
          {errors.map((error) => <p key={error} className={styles.Error}>{error}</p>)}
          <div className={styles.AgeInput}>
            Age:
            <button
              type="button"
              disabled={age === 1}
              onClick={decreaseAge}
              className={styles.AgeControl}
            >
              -
            </button>
            {age}
            <button
              type="button"
              onClick={increaseAge}
              className={styles.AgeControl}
            >
              +
            </button>
          </div>
        </form>
        <div className={styles.UserInput}>
          <p>Name: {name}</p>
          <p>Age: {age}</p>
        </div>
      </div>
    </div>
  );
};

export default App;
