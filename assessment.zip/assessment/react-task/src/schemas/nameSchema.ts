import { z } from "zod";

import { CHARCTERS_ONLY_REGEX } from "../constants";

export const nameSchema = z
  .string()
  .max(20, "Name cannot exceed 20 characters.")
  .regex(CHARCTERS_ONLY_REGEX, "Name can only include letters.");
